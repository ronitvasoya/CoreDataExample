
import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var arr : [Any] = []
   
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtid: UITextField!
    @IBOutlet weak var txtadd: UITextField!
    @IBOutlet weak var txtname: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        create()
        
    }
    
    func create()
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity
        do
        {
            arr = try context.fetch(request)
        }
        catch{}
    }
    
    func clear()
    {
        txtid.text = ""
        txtname.text = ""
        txtadd.text = ""
    }
    
    @IBAction func btnInsert(_ sender: Any)
    {
        let entity = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context)
        entity.setValue(Int(txtid.text!), forKey: "id")
        entity.setValue(txtname.text!, forKey: "name")
        entity.setValue(txtadd.text!, forKey: "add")
        do
        {
            try context.save()
            clear()
        }
        catch{}
        create()
        tbl.reloadData()
    }
    
    @IBAction func btnUpdate(_ sender: Any)
    {
            let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
            request.entity = entity
            let pred = NSPredicate(format: "id = %@", txtid.text!)
            request.predicate = pred
        do
        {
            var arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject
                obj.setValue(Int(txtid.text!), forKey: "id")
                obj.setValue(txtname.text, forKey: "name")
                obj.setValue(txtadd.text, forKey: "add")
                do
                {
                    try context.save()
                }
                catch{}
            }
        }
        catch{}
        create()
        tbl.reloadData()
    }
    
    @IBAction func btnDelete(_ sender: Any)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity
        let pred = NSPredicate(format: "id = %@", txtid.text!)
        request.predicate = pred
        do
        {
            var arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject
                context.delete(obj)
                do
                {
                    try context.save()
                }
                catch{}
            }
        }
        catch{}
        create()
        tbl.reloadData()
    }
    
    
    @IBAction func btnSelect(_ sender: Any)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity
        let pred = NSPredicate(format: "id = %@", txtid.text!)
        request.predicate = pred
        do
        {
            arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject
                txtid.text = String(obj.value(forKey: "id") as! Int)
                txtname.text  =  obj.value(forKey: "name") as! String?
                txtadd.text = obj.value(forKey: "add") as! String?
            }
        }
        catch{}
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell
        if arr.count > 0
        {
                let obj = arr[indexPath.row] as! NSManagedObject
                cell.lblid.text = String(obj.value(forKey: "id") as! Int)
                cell.lblname.text  =  obj.value(forKey: "name") as! String?
                cell.lbladd.text = obj.value(forKey: "add") as! String?
                
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
            if arr.count > 0
            {
                let obj = arr[indexPath.row] as! NSManagedObject
                txtid.text = String(obj.value(forKey: "id") as! Int)
                txtname.text  =  obj.value(forKey: "name") as! String?
                txtadd.text = obj.value(forKey: "add") as! String?
            }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }


}

